$(document).ready(function(){

$('.alert').fadeOut(5000);

// $("#logUser").click(function(){
//   $('#adm').parent().addClass('in');
//   console.log('logUser clicked !!');
// });




});
